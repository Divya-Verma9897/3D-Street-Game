package com.brainmentors.game.canvas;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;

import com.brainmentors.game.utils.Constant;
import jaco.mp3.player.MP3Player;

public class SplashScreen  extends JFrame implements Constant{
    private JLabel label=new JLabel() ;
    private MP3Player player1;
    public SplashScreen (){
        setTitle(TITLE);
        // setExtendedState(MAXIMIZED_BOTH);
		setSize(SCREENWIDTH, SCREENHEIGHT);
        setLocationRelativeTo(null);
		setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        loadMusic();
        
        Icon ic=new ImageIcon(SplashScreen.class.getResource(Splash));
        label.setIcon(ic);
        this.add(label);
        setVisible(true);
             try {
                Thread.sleep(100);
                setVisible(false);
                dispose();
                player1.stop();
			GameFrame obj = new GameFrame();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
        
    
        private void  loadMusic(){
           player1 =new MP3Player(SplashScreen.class.getResource("Splash.mp3"));
           player1.play();
        }
    public static void main(String[] args) {
        SplashScreen s=new SplashScreen();
    }
}
