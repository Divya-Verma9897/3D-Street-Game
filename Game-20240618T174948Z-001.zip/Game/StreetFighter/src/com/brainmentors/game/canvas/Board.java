package com.brainmentors.game.canvas;

import java.awt.Color;
import java.awt.Font;
//import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Date;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
// import javax.swing.Timer;
import javax.swing.Timer;

import com.brainmentors.game.sprites.Health;
import com.brainmentors.game.sprites.OpponentPlayer;
import com.brainmentors.game.sprites.Player;
import com.brainmentors.game.sprites.Power;
// import com.brainmentors.game.sprites.OpponentPlayer;
import com.brainmentors.game.sprites.Player;
import com.brainmentors.game.utils.Constant;

import jaco.mp3.player.MP3Player;

public class Board extends JPanel implements Constant {
    BufferedImage imageBg;
    private Player player;
    private Timer timer;
    private OpponentPlayer opponentPlayer;
    private Health kenHealth;
    private Health reuHealth;
    private boolean GameOver;
    private MP3Player start,punchmusic,Kickmusic;
    private void  loadStartMusic(){
       start=new MP3Player(SplashScreen.class.getResource("GameBoard.mp3"));
       start.play();
      
     }
     private void  loadEndMusic(){
        new MP3Player(SplashScreen.class.getResource("GameOver.mp3")).play();;   
      }

      private void  loadPunchMusic(){
        punchmusic=new MP3Player(SplashScreen.class.getResource("punch.mp3"));
        punchmusic.play();
       
      }
      private void  loadKickMusic(){
        Kickmusic=new MP3Player(SplashScreen.class.getResource("Kick.mp3"));
        Kickmusic.play();
       
      }


    private void isGameover(){
if(reuHealth.getHealth()<=0 || kenHealth.getHealth()<=0){
    GameOver=true;
}
}

private void printGameover(Graphics pen){
if(GameOver){
start.stop();
pen.setColor(Color.RED);
loadEndMusic();
pen.setFont(new Font("times",Font.BOLD,60));
pen.drawString("Game Over",230,200);

        }
    }

    public Board() throws IOException {
        player = new Player();
        opponentPlayer = new OpponentPlayer();
        loadBackground();
        gameLoop();
        setFocusable(true);
        bindEvent();
        LoadHealth();
        loadStartMusic();
        
    }
    
    private void LoadHealth(){
        kenHealth = new Health(30, Color.WHITE,"Ken");
        reuHealth=new Health(SCREENWIDTH-600, Color.WHITE,"Reu");
    }
    private void printHealth(Graphics pen){
        kenHealth.printHealthBar(pen);
        reuHealth.printHealthBar(pen);
    }
private void gameLoop(){
timer =new Timer(150, new ActionListener() {
    
    @Override
    public void actionPerformed(ActionEvent arg0) {
        // System.out.println("Hello  ");
        // Date d=new Date();
        // System.out.println(d);
        player.fall();
        opponentPlayer.fall();
        repaint();
        isGameover();
        collison();
        if(GameOver){
            timer.stop();
        }
    }
    
});
timer.start();
}

private boolean iscollied(){
int xdistance=Math.abs(player.getX()-opponentPlayer.getX());
int ydistance=Math.abs(player.getY()-opponentPlayer.getY());
int MaxW=Math.max(player.getW(),opponentPlayer.getW());
int Maxh=Math.max(player.getH(),player.getH());
return xdistance <=MaxW && ydistance <=Maxh;
}
private void collison(){
    if(iscollied()){

        if(player.isAttacking() && opponentPlayer.isAttacking()){

        }
        else if(player.isAttacking()){
        opponentPlayer.setCurrentMove(HIT);
        reuHealth.setHealth();
        }
        else if(opponentPlayer.isAttacking()){

        }

        player.setcollied(true); 
        opponentPlayer.setcollied(true);  
    //     opponentPlayer.setcollied(true);   //doubt
    //     System.out.println("Collision");
        player.setSpeed(0);
        opponentPlayer.setSpeed(0);
    }
    else{
        player.setSpeed(SPEED);
        opponentPlayer.setSpeed(SPEED);
        opponentPlayer.setcollied(false);
        player.setcollied(false);
    }
}
    @Override
    public void paintComponent(Graphics pen) {
        showBackground(pen);
        player.drawPlayer(pen);
        opponentPlayer.drawPlayer(pen);
        printHealth(pen);
        printGameover(pen);
        printPower(pen);
    }

    private void bindEvent() {
        KeyListener k = new KeyListener() {
            @Override
            public void keyPressed(KeyEvent arg0) {
                System.out.println("Pressed " + arg0.getKeyCode());

                if (arg0.getKeyCode() == KeyEvent.VK_A) {
                    player.setcollied(false);
                    player.setSpeed(-10);
                    player.move();
                    player.setCurrentMove(WALK);
                    // repaint();a
                }
                else if(arg0.getKeyCode()==KeyEvent.VK_D){
                    player.setCurrentMove(PUNCH);
                    start.stop();
                    loadPunchMusic();
                    start.play();
                    // player.setAttacking(true);
                }
                else if(arg0.getKeyCode()==KeyEvent.VK_Q){
                   player.setCurrentMove(POWER);
                   player.showpower();
                    // player.setAttacking(true);
                }
                else if (arg0.getKeyCode() == KeyEvent.VK_F) {
                    player.setSpeed(10);
                    player.move();
                    // player.setAttacking(true);
                    // player.setCurrentMove(WALK);
                   
                    // repaint();
                }
                else if(arg0.getKeyCode() == KeyEvent.VK_Z) {
					player.setCurrentMove(KICK);
                    start.stop();
                    loadKickMusic();
                     start.play();
                    opponentPlayer.setCurrentMove(HIT);
                   
				}
else if(arg0.getKeyCode()==KeyEvent.VK_SPACE){
    player.jump();
}
                else if (arg0.getKeyCode() == LEFTKEY) {
                  
                    opponentPlayer.setSpeed(-10);
                    opponentPlayer.move();
                    opponentPlayer.setCurrentMove(WALK);
                    // repaint();
                }
                else if (arg0.getKeyCode() == RIGHTKEY) {
                     opponentPlayer.setcollied(false);
                    opponentPlayer.setSpeed(10);
                    opponentPlayer.setCurrentMove(WALK);
                    opponentPlayer.move();
                    // repaint();
                }

                else if(arg0.getKeyCode()==KeyEvent.VK_P){
                    opponentPlayer.setCurrentMove(PUNCH);
                    start.stop();
                    loadPunchMusic();
                    start.play();
                }
                else if(arg0.getKeyCode()==KeyEvent.VK_J){
                    opponentPlayer.jump();
                }
                else if(arg0.getKeyCode()==KeyEvent.VK_K){
                    opponentPlayer.setCurrentMove(KICK);
                    start.stop();
                    loadKickMusic();
                    start.play();
                }
                // if(arg0.getKeyCode()==LEFTKEY){
                // opponentPlayer.move();
                // }
            }

            @Override
            public void keyReleased(KeyEvent arg0) {
                System.out.println("Released " + arg0.getKeyCode());
            }

            @Override
            public void keyTyped(KeyEvent arg0) {
                System.out.println("Typed  " + arg0.getKeyCode());
            }
            
        };
        this.addKeyListener(k);
    }

    private void printPower(Graphics pen){
        for(Power power:player.getpower()){
            power.printPower(pen);
        }
    }

    private void showBackground(Graphics pen) {
        // image, x, y, w, h
        pen.drawImage(imageBg, 0, 0, SCREENWIDTH, SCREENHEIGHT, null);
    }

    private void loadBackground() {
        try {
            imageBg = ImageIO.read(Board.class.getResource("bg_2.jpg"));
        } catch (IOException e) {
            System.out.println("Failed to load background image...");
            System.exit(0);
        }
    }

}