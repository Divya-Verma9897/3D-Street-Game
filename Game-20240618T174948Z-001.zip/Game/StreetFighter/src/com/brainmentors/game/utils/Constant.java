package com.brainmentors.game.utils;

public interface Constant {
	String TITLE = "Street Fighter By Brain Mentors";
	int SCREENHEIGHT = 800;
	int SCREENWIDTH = 1500;
	int FLOOR = SCREENHEIGHT - 300;
	int LEFTKEY = 37;
	String Splash="splash1.jpeg";
	int RIGHTKEY = 39;
	int SPEED=10;
	int MAXHEALTH=450;
	int HIT=5;
	int POWER=6;
// int DKEY=68;
// int AKEY=65;
// int FKEY=70;
  
	int IDLE = 1;
	int WALK = 2;
	int KICK = 3;
	int PUNCH = 4;
	int GRAVITY=9;
	
}
