package com.brainmentors.game.sprites;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.lang.invoke.ConstantCallSite;
import java.awt.color.*;
public class Health extends CommonPlayer{


private Color color;
private String name;
public Health(int x , Color color ,String name){
this.x=x;
y=20;
h=50;
w=450;
this.name=name;
this.color=color;

}

public void printHealthBar(Graphics pen){
    pen.setColor(Color.RED);
    pen.fillRect(x, y,w,h);
    if(health>0){
        pen.setColor(color);
        pen.fillRect(x, y, health,h);
        pen.setFont(new Font("times", Font.BOLD, 50));
    }
    // pen.setColor(color);
		// pen.fillRect(x, y, w, h);
		pen.setColor(Color.WHITE);
		pen.drawString(this.name, x, y + 100);
}

@Override
public BufferedImage defalutImage() {
    // TODO Auto-generated method stub
    throw new UnsupportedOperationException("Unimplemented method 'defalutImage'");
}
   
    
}
