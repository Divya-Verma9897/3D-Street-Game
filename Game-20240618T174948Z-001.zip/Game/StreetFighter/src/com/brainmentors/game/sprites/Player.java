package com.brainmentors.game.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import com.brainmentors.game.utils.Constant;

public class Player extends CommonPlayer implements Constant {
    private BufferedImage[] idleImages=new BufferedImage[4];
    private BufferedImage[] walkImages=new BufferedImage[5];
    private BufferedImage[] punchImages=new BufferedImage[3];
    private BufferedImage[] kickImages=new BufferedImage[5];
    private BufferedImage[] PowerImages=new BufferedImage[4];
    private int force=0;
 public Player () throws IOException{
    
    x=500;
    w=120;
    h=150;
    y=FLOOR;
     
PlayerImage=ImageIO.read(Player.class.getResource("ken_.png"));
loadIdleImage();
loadWalkImage();
loadPunch();
loadKickImages();
loadPowerImage();


}

public void jump(){
force=-30;
y=y+force;
}

public void fall(){
    if(y+force>FLOOR){
        return ;
    }
    force=force+GRAVITY;
    y=y+force;
}

private void loadIdleImage(){
    idleImages[0]=PlayerImage.getSubimage(49,242,106,250);
    idleImages[1]=PlayerImage.getSubimage(267,241,107,247);
    idleImages[2]=PlayerImage.getSubimage(476,243,113,245);
    idleImages[3]=PlayerImage.getSubimage(685,246,113,243);
}
private void loadPowerImage(){
    PowerImages[0]=PlayerImage.getSubimage(29,10,155,224);
    PowerImages[1]=PlayerImage.getSubimage(240,10,161,224);
    PowerImages[2]=PlayerImage.getSubimage(439,26,197,206);
    PowerImages[3]=PlayerImage.getSubimage(660,26,193,206);
}

private void loadPunch(){
    punchImages[0]=PlayerImage.getSubimage(42,489,120,242);
    punchImages[1]=PlayerImage.getSubimage(258,489,169,242);
    punchImages[2]=PlayerImage.getSubimage(475,489,117,242);

}

private void loadKickImages() {
    kickImages[0] = PlayerImage.getSubimage(43, 1461, 130, 243);
    kickImages[1] = PlayerImage.getSubimage(245, 1462, 127, 240);
    kickImages[2] = PlayerImage.getSubimage(426, 1462, 210, 240);
    kickImages[3] = PlayerImage.getSubimage(245, 1462, 127, 240);
    kickImages[4] = PlayerImage.getSubimage(43, 1461, 130, 243);
}

private void loadWalkImage(){
    walkImages[0]=PlayerImage.getSubimage(43,735,113,239);
    walkImages[1]=PlayerImage.getSubimage(255,731,120,243);
    walkImages[2]=PlayerImage.getSubimage(472,731,102,243);
    walkImages[3]=PlayerImage.getSubimage(694,731,100,243);
    walkImages[4]=PlayerImage.getSubimage(908,747,97,227);
}



public BufferedImage printidle(){
    if(imageIndex>3){
        imageIndex=0;
    }
    // return  PlayerImage.getSubimage(41,737,119,237);
  BufferedImage BI=idleImages[imageIndex];
  imageIndex++;
  return BI;
}
public BufferedImage printPower(){
    if(imageIndex>3){
        imageIndex=0;
    }
    // return  PlayerImage.getSubimage(41,737,119,237);
  BufferedImage BI=PowerImages[imageIndex];
  imageIndex++;
  return BI;
}

public BufferedImage printWalk(){
    if(imageIndex>4){
        imageIndex=0;
    }
    // return  PlayerImage.getSubimage(41,737,119,237);
  BufferedImage BI=walkImages[imageIndex];
  imageIndex++;
  return BI;
}

public BufferedImage printpuch(){
    isAttacking=true;
    if(imageIndex>2){
        imageIndex=0;
        currentMove=IDLE;
        isAttacking=false;
    }
    // return  PlayerImage.getSubimage(41,737,119,237);
  BufferedImage BI=punchImages[imageIndex];
  imageIndex++;
  return BI;
}

public BufferedImage printKick() {
    isAttacking=true;
    if(imageIndex > 2) {
        imageIndex = 0;
        currentMove = IDLE;
        isAttacking=false;
    }
    BufferedImage img = kickImages[imageIndex];
    imageIndex++;
    return img;
}
private ArrayList<Power>power=new ArrayList<>();
public ArrayList<Power> getpower(){
    return power;
}
public void showpower(){
   power.add(new Power(x+w-50,y+h/2,PlayerImage));
}

@Override
public BufferedImage defalutImage() {
    if(currentMove==WALK){
        return printWalk();
    }
    else if(currentMove==PUNCH){
        return printpuch();
    }

    else if(currentMove==KICK){
        return printKick();
    }
    else if(currentMove==POWER){
        return printPower();
    }
    else 
    {

        return printidle();
    }
}


// X = 41 Y = 737
// Width = 119 Height = 237



}

