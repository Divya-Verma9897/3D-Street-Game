package com.brainmentors.game.sprites;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

import com.brainmentors.game.utils.Constant;

public abstract class CommonPlayer implements Constant {
    public int getCurrentMove() {
        return currentMove;
    }
    public boolean isIscollied() {
        return iscollied;
    }
    public void setcollied(boolean iscollied) {
        this.iscollied = iscollied;
    }
    public int getHealth() {
        return health;
    }
    public boolean isAttacking() {
        return isAttacking;
    }
    public void setAttacking(boolean isAttacking) {
        this.isAttacking = isAttacking;
    }
    public void setHealth() {
        this.health = (int)(health-MAXHEALTH*0.08);
    }
    public void setCurrentMove(int currentMove) {
        this.currentMove = currentMove;
    }
    protected int x;
    protected int y;
    protected int w;
    protected int h;
    protected int health;
    protected int currentMove;
    protected int imageIndex;
    protected boolean iscollied;
    protected boolean isAttacking;
    protected int speed;
  public abstract BufferedImage defalutImage();
    protected BufferedImage PlayerImage;

    public CommonPlayer(){
        health=MAXHEALTH;
    }

    public int getX() {
    return x;
}
public void setX(int x) {
    this.x = x;
}
public int getY() {
    return y;
}
public void setY(int y) {
    this.y = y;
}
public int getW() {
    return w;
}
public void setW(int w) {
    this.w = w;
}
public int getH() {
    return h;
}
public void setH(int h) {
    this.h = h;
}
public int getSpeed() {
    return speed;
}
public void setSpeed(int speed) {
    this.speed = speed;
}

public BufferedImage getPlayerImage() {
    return PlayerImage;
}
public void setPlayerImage(BufferedImage playerImage) {
    PlayerImage = playerImage;
}
    public void drawPlayer(Graphics pen){

        // pen.drawImage(PlayerImage,x,y,w,h,null);
        pen.drawImage(defalutImage(),x,y,w,h,null);
        }
        
    
        public void move(){
            if(!iscollied){

                x=x+speed;
            }
        }
        // public void hitt(){

        //     if(currentMove==Player.PUNCH){
        //  return printHit();
        //     }
        // }
        // public boolean Collied(){
        //     return ;
        // }
}
