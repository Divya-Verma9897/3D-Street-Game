package com.brainmentors.game.sprites;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

public class Power extends CommonPlayer{

    public Power(int x,int y,BufferedImage img){
        this.PlayerImage=img;
        this.x=x+20;
        this.y=y-50;
        w=50;
        h=50;
        speed=70;

    }

    @Override
    public BufferedImage defalutImage() {
       return PlayerImage.getSubimage(30,1028,98,82);
    }
    public void printPower(Graphics pen){
        pen.drawImage(defalutImage(),x,y,w,h,null);
        move();
    }

   
    
}
