package com.brainmentors.game.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.brainmentors.game.utils.Constant;

public class OpponentPlayer extends CommonPlayer implements Constant {
    private BufferedImage[] idleImages=new BufferedImage[5];
    private BufferedImage[] walkImages=new BufferedImage[5];
    private BufferedImage[] punchImages=new BufferedImage[5];
    private BufferedImage[] kickImages=new BufferedImage[4];
    private BufferedImage hitImages[] = new BufferedImage[3];
    private int force=0;
 public OpponentPlayer () throws IOException{
    x=SCREENWIDTH-600;
    w=120;
    h=150;
    y=FLOOR;
    

PlayerImage=ImageIO.read(OpponentPlayer.class.getResource("ryu_.png"));
loadIdleImage();
loadWalkImage();
loadPunch();
loadHitImages();
loadKickImage();
}

public void jump(){
    force=-30;
    y=y+force;
    }
    
    public void fall(){
        if(y+force>FLOOR){
            return ;
        }
        force=force+GRAVITY;
        y=y+force;
    }

private void loadIdleImage(){
    idleImages[0]=PlayerImage.getSubimage(2174,47,89,218);
    idleImages[1]=PlayerImage.getSubimage(2357,37,107,231);
    idleImages[2]=PlayerImage.getSubimage(2555,34,109,233);
    idleImages[3]=PlayerImage.getSubimage(2747,38,106,230);
    idleImages[4]=PlayerImage.getSubimage(2958,41,105,227);
}
private void loadPunch(){
    punchImages[0]=PlayerImage.getSubimage(2940,1227,111,226);
    punchImages[1]=PlayerImage.getSubimage(2731,1215,135,238);
    punchImages[2]=PlayerImage.getSubimage(2491,1215,186,238);
    punchImages[3]=PlayerImage.getSubimage(2731,1215,135,238);
    punchImages[4]=PlayerImage.getSubimage(2940,1227,111,226);

}

private void loadWalkImage(){
    walkImages[0]=PlayerImage.getSubimage(2960,329,92,217);
    walkImages[1]=PlayerImage.getSubimage(2758,317,111,229);
    walkImages[2]=PlayerImage.getSubimage(2575,313,107,233);
    walkImages[3]=PlayerImage.getSubimage(2392,313,98,231);
    walkImages[4]=PlayerImage.getSubimage(2211,313,94,231);
}

private void loadKickImage(){
  
    kickImages[0]=PlayerImage.getSubimage(2952,891,102,236);
    kickImages[1]=PlayerImage.getSubimage(2762,887,117,239);
    kickImages[2]=PlayerImage.getSubimage(2497,885,196,243);
    kickImages[3]=PlayerImage.getSubimage(2315,888,115,235);
  
}



private void loadHitImages() {
    hitImages[0] = PlayerImage.getSubimage(995, 1578, 123, 250);
    hitImages[1] = PlayerImage.getSubimage(1171, 1574, 147, 238);
    hitImages[2] = PlayerImage.getSubimage(1374, 1583, 124, 229);
}

public BufferedImage printHit() {
    // X = 2750 Y = 40
    // isAttacking=false
    if(imageIndex > 2) {
        imageIndex = 0;
        // isAttacking=false;
        currentMove = IDLE;
    }
    BufferedImage img = hitImages[imageIndex];
    imageIndex++;
    return img;
    }
    
public BufferedImage printWalk(){
    if(imageIndex>4){
        imageIndex=0;
    }
    // return  PlayerImage.getSubimage(41,737,119,237);
    BufferedImage BI=walkImages[imageIndex];
  imageIndex++;
  return BI;
}

public BufferedImage printKick(){
    if(imageIndex>3){
        imageIndex=0;
    }
    // return  PlayerImage.getSubimage(41,737,119,237);
  BufferedImage BI=kickImages[imageIndex];
  imageIndex++;
  return BI;
}
public BufferedImage printpuch(){
    if(imageIndex>4){
        imageIndex=0;
    }
    // return  PlayerImage.getSubimage(41,737,119,237);
    BufferedImage BI=punchImages[imageIndex];
  imageIndex++;
  return BI;
}

public BufferedImage printidle(){
    if(imageIndex>4){
        imageIndex=0;
    }
    // return  PlayerImage.getSubimage(41,737,119,237);
    BufferedImage BI=idleImages[imageIndex];
    imageIndex++;
    return BI;
}
    // Width = 103 Height = 230
 @Override
 public BufferedImage defalutImage() {
     if(currentMove==WALK){
         return printWalk();
     }
     else if(currentMove==PUNCH){
        return printpuch();
    }
    else if(currentMove==KICK){
        return printKick();
    }
    
    else    {

        return printidle();
    }


}
 }


 